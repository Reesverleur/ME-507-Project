var class_pixy2 =
[
    [ "Pixy2", "class_pixy2.html#aead5ae3d4ebc59d35fdc8faae3ee3797", null ],
    [ "getBlock", "class_pixy2.html#acd9f3a548eed9c7348c14619affbab9b", null ],
    [ "setCoords", "class_pixy2.html#ad7032b25bbeaacbadbfea0f4a63b9ada", null ],
    [ "Block", "class_pixy2.html#a1f52f01612a384324ca724557f3b660e", null ],
    [ "Coords", "class_pixy2.html#acb15871ec0ff4bc7e4dff74c51131c89", null ],
    [ "Data", "class_pixy2.html#aa8af39f57cd9f4fe191fc560ef761926", null ],
    [ "Length", "class_pixy2.html#af70f3d006ec88c0ea52f500938413230", null ],
    [ "spi", "class_pixy2.html#a49f19b0f16a7f2aac4ed828f308c547d", null ],
    [ "SS_Pin", "class_pixy2.html#af55d898a6bde47ead0588ea66aed2b1c", null ],
    [ "SS_Port", "class_pixy2.html#a75a4ee39e2cecd3391825d84cfbb5020", null ],
    [ "StartByte", "class_pixy2.html#aaa32690b46c6fc32298c63eaa48be9a6", null ]
];