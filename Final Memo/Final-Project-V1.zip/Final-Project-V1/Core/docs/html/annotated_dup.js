var annotated_dup =
[
    [ "coms", "classcoms.html", "classcoms" ],
    [ "CSens", "class_c_sens.html", "class_c_sens" ],
    [ "Motor", "class_motor.html", "class_motor" ],
    [ "Pixy2", "class_pixy2.html", "class_pixy2" ]
];