var searchData=
[
  ['variablecontrol_0',['VariableControl',['../class_motor.html#a2d78e1dd7a81217ea192b9d8a8919db5',1,'Motor']]]
];
