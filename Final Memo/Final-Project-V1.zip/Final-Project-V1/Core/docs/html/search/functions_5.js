var searchData=
[
  ['get_5finfo_0',['get_info',['../namespace_communication.html#aeff85c26730689a3661104879b0a995c',1,'Communication']]],
  ['getblock_1',['getBlock',['../class_pixy2.html#acd9f3a548eed9c7348c14619affbab9b',1,'Pixy2']]],
  ['getcdata_2',['getCdata',['../class_c_sens.html#a4f6a194a321d5e50883bc19add1067b4',1,'CSens']]]
];
