var searchData=
[
  ['ticks_0',['ticks',['../class_motor.html#a1488c62593760ccd830dd139a226d149',1,'Motor']]],
  ['tim_1',['tim',['../class_motor.html#a1867a8b2977e1babab19e7e87db8ce07',1,'Motor']]],
  ['timeout_2',['timeout',['../namespace_communication.html#a82e143310a516ac846fc4d4158141af6',1,'Communication']]],
  ['translate_3',['translate',['../classcoms.html#ae69d3c4e4691b8fd6f78a66db1eb2657',1,'coms']]]
];
