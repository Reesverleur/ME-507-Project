var searchData=
[
  ['i2c_0',['i2c',['../class_c_sens.html#aa66efdc9555b448606dc65cea90795cc',1,'CSens']]],
  ['idx_1',['idx',['../namespace_communication.html#a8320afb477e6d9ccafe700582fee6b91',1,'Communication']]],
  ['init_2',['Init',['../class_c_sens.html#a954998c99aaddec66864fae3ac90ff60',1,'CSens']]]
];
