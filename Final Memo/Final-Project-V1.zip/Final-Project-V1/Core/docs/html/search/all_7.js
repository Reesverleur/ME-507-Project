var searchData=
[
  ['gear_0',['gear',['../classcoms.html#af46ef7b1dfe9a2dd9a30bb441b035e1c',1,'coms']]],
  ['get_5finfo_1',['get_info',['../namespace_communication.html#aeff85c26730689a3661104879b0a995c',1,'Communication']]],
  ['getblock_2',['getBlock',['../class_pixy2.html#acd9f3a548eed9c7348c14619affbab9b',1,'Pixy2']]],
  ['getcdata_3',['getCdata',['../class_c_sens.html#a4f6a194a321d5e50883bc19add1067b4',1,'CSens']]],
  ['grn_5fval_4',['Grn_Val',['../class_c_sens.html#abf222dae6f684d88df32237e3a8315be',1,'CSens']]]
];
