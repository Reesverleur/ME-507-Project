var searchData=
[
  ['parity_0',['parity',['../namespace_communication.html#ac71e8b632d40bd33c719d06092fc4d27',1,'Communication']]],
  ['phi_1',['phi',['../namespace_communication.html#ae54bbb9805537bce5f111a48420610f6',1,'Communication']]],
  ['pos_2',['Pos',['../class_motor.html#a913de2f1a084b5eaa30278c3a70dbc0a',1,'Motor']]]
];
