var searchData=
[
  ['cdata_0',['Cdata',['../class_c_sens.html#abde882476a99649f3ab7e77de065964f',1,'CSens']]],
  ['clr_5fval_1',['Clr_Val',['../class_c_sens.html#a96bf5467865d3114c8615064c7819b28',1,'CSens']]],
  ['color_2',['color',['../namespace_communication.html#a3520cde1d9b046549a5679fd2f1567f0',1,'Communication']]],
  ['coords_3',['Coords',['../class_pixy2.html#acb15871ec0ff4bc7e4dff74c51131c89',1,'Pixy2']]],
  ['cpr_4',['cpr',['../classcoms.html#a306970d649634b9cbd59f9d80f71fd58',1,'coms']]]
];
