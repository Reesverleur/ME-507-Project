var searchData=
[
  ['memaddr_0',['MemAddr',['../class_c_sens.html#af53cda980242c8157481250149f9f64e',1,'CSens']]],
  ['messbuff_1',['messbuff',['../classcoms.html#a2f9faae9e70f59ae9b252a255147ae79',1,'coms']]]
];
