var searchData=
[
  ['oldticks_0',['oldticks',['../class_motor.html#a17dda9f9427518acfc75b1a93dfef5de',1,'Motor']]]
];
