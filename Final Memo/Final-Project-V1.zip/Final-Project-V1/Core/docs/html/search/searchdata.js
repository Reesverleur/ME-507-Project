var indexSectionsWithContent =
{
  0: "_abcdefghiklmnoprstuvwxyz",
  1: "cmp",
  2: "c",
  3: "cmps",
  4: "_bcdeghimnprsuvz",
  5: "_abcdefghiklmnoprstuwxy",
  6: "cs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Modules"
};

