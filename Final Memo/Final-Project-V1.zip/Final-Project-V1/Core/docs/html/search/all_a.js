var searchData=
[
  ['kd_0',['Kd',['../class_motor.html#a6c87513f80d274f8d44b170cae3be677',1,'Motor']]],
  ['ki_1',['Ki',['../class_motor.html#a435009b7289c271f82abe4a48f4f3465',1,'Motor']]],
  ['kp_2',['Kp',['../class_motor.html#adf4a9300dd9db97cee93305fbe324827',1,'Motor']]]
];
