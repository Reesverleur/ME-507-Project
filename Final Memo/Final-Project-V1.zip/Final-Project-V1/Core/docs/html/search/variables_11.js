var searchData=
[
  ['serialobj_0',['SerialObj',['../namespace_communication.html#ad220bbc7e70e70a32678128de9d9fa3d',1,'Communication']]],
  ['setpoint_1',['setpoint',['../class_motor.html#ab6855c76809c900fcc0ceb51325fbbf7',1,'Motor']]],
  ['spi_2',['spi',['../class_pixy2.html#a49f19b0f16a7f2aac4ed828f308c547d',1,'Pixy2']]],
  ['ss_5fpin_3',['SS_Pin',['../class_pixy2.html#af55d898a6bde47ead0588ea66aed2b1c',1,'Pixy2']]],
  ['ss_5fport_4',['SS_Port',['../class_pixy2.html#a75a4ee39e2cecd3391825d84cfbb5020',1,'Pixy2']]],
  ['start_5',['start',['../classcoms.html#a54eae3337175c32e900a04401461866e',1,'coms::start'],['../namespace_communication.html#a0ac406e3fd08e8224cbb56c92d534c76',1,'Communication.start']]],
  ['startbyte_6',['StartByte',['../class_pixy2.html#aaa32690b46c6fc32298c63eaa48be9a6',1,'Pixy2']]],
  ['stopbits_7',['stopbits',['../namespace_communication.html#a5f2260f692856d7d68acc081e1ad882d',1,'Communication']]],
  ['systemcoreclock_8',['SystemCoreClock',['../group___s_t_m32_f4xx___system___private___variables.html#gaa3cd3e43291e81e795d642b79b6088e6',1,'system_stm32f4xx.c']]]
];
