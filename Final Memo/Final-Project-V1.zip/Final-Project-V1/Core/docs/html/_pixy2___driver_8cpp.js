var _pixy2___driver_8cpp =
[
    [ "HAL_SPI_RxCpltCallback", "_pixy2___driver_8cpp.html#a3df7021fe24cf874f8b1eec5bd5f4cb3", null ],
    [ "HAL_SPI_TxCpltCallback", "_pixy2___driver_8cpp.html#a0a99ab4f6aa6ee7dc2abca5483910dde", null ]
];