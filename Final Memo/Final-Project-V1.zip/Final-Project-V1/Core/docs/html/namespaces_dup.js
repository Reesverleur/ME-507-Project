var namespaces_dup =
[
    [ "Communication", "namespace_communication.html", [
      [ "get_info", "namespace_communication.html#aeff85c26730689a3661104879b0a995c", null ],
      [ "rss", "namespace_communication.html#acd8cafd8f5c5a5343e663c25148d2bbc", null ],
      [ "angle", "namespace_communication.html#afc936ae1be897ea15fe859aca179150c", null ],
      [ "balls", "namespace_communication.html#ab92b364153abcdaebcdf720d82548df9", null ],
      [ "baudrate", "namespace_communication.html#a6cf3dbaecccf7826e53f285d8064b33c", null ],
      [ "bindex", "namespace_communication.html#a470cbc741e27fca278913a038166e85c", null ],
      [ "bytesize", "namespace_communication.html#ae557f97a5b53d4bb9c207ba6ae77a062", null ],
      [ "color", "namespace_communication.html#a3520cde1d9b046549a5679fd2f1567f0", null ],
      [ "dist", "namespace_communication.html#a142fbaa4648fe7b45a798a8030019199", null ],
      [ "distance", "namespace_communication.html#ae832d97bb3f9b275c11e03839109fd4f", null ],
      [ "idx", "namespace_communication.html#a8320afb477e6d9ccafe700582fee6b91", null ],
      [ "n", "namespace_communication.html#a5e0e966415666366c570a202cde07525", null ],
      [ "parity", "namespace_communication.html#ac71e8b632d40bd33c719d06092fc4d27", null ],
      [ "phi", "namespace_communication.html#ae54bbb9805537bce5f111a48420610f6", null ],
      [ "req", "namespace_communication.html#a8bff2b2773c8e14207fe73e47411d447", null ],
      [ "robots", "namespace_communication.html#a78d82ad6303544338716197dd292e2d2", null ],
      [ "SerialObj", "namespace_communication.html#ad220bbc7e70e70a32678128de9d9fa3d", null ],
      [ "start", "namespace_communication.html#a0ac406e3fd08e8224cbb56c92d534c76", null ],
      [ "stopbits", "namespace_communication.html#a5f2260f692856d7d68acc081e1ad882d", null ],
      [ "timeout", "namespace_communication.html#a82e143310a516ac846fc4d4158141af6", null ],
      [ "xtrans", "namespace_communication.html#a1547b1fa75ac1591f35066e7c823e077", null ],
      [ "ytrans", "namespace_communication.html#aff5e008a50563c357fe02ef2cc72b22c", null ]
    ] ]
];