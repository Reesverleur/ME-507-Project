var class_c_sens =
[
    [ "CSens", "class_c_sens.html#ae46e479c302727c5c0b9d255f53dc525", null ],
    [ "getCdata", "class_c_sens.html#a4f6a194a321d5e50883bc19add1067b4", null ],
    [ "Address", "class_c_sens.html#ad7bf06677399ec1ed5a406aa537f61b3", null ],
    [ "Blu_Val", "class_c_sens.html#aa99d02835daf65e4baa53f817778a4af", null ],
    [ "Cdata", "class_c_sens.html#abde882476a99649f3ab7e77de065964f", null ],
    [ "Clr_Val", "class_c_sens.html#a96bf5467865d3114c8615064c7819b28", null ],
    [ "Grn_Val", "class_c_sens.html#abf222dae6f684d88df32237e3a8315be", null ],
    [ "i2c", "class_c_sens.html#aa66efdc9555b448606dc65cea90795cc", null ],
    [ "Init", "class_c_sens.html#a954998c99aaddec66864fae3ac90ff60", null ],
    [ "Length", "class_c_sens.html#a482786ce0e9d5da99ce243c13500374a", null ],
    [ "MemAddr", "class_c_sens.html#af53cda980242c8157481250149f9f64e", null ],
    [ "Red_Val", "class_c_sens.html#a5ecef084ece6e281c72789920f7412dc", null ]
];