var coms_8h =
[
    [ "coms", "classcoms.html", "classcoms" ],
    [ "HAL_UART_RxCpltCallback", "coms_8h.html#ae494a9643f29b87d6d81e5264e60e57b", null ],
    [ "HAL_UART_TxCpltCallback", "coms_8h.html#abcdf9b59049eccbc87d54042f9235b1a", null ]
];