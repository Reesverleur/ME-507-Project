var searchData=
[
  ['setcoords_0',['setCoords',['../class_pixy2.html#ad7032b25bbeaacbadbfea0f4a63b9ada',1,'Pixy2']]],
  ['setgains_1',['setGains',['../class_motor.html#ac3edc48cd9375328a110a5d209729262',1,'Motor']]],
  ['svc_5fhandler_2',['SVC_Handler',['../stm32f4xx__it_8c.html#a3e5ddb3df0d62f2dc357e64a3f04a6ce',1,'stm32f4xx_it.c']]],
  ['systemclock_5fconfig_3',['SystemClock_Config',['../main_8c.html#a70af21c671abfcc773614a9a4f63d920',1,'main.c']]],
  ['systemcoreclockupdate_4',['SystemCoreClockUpdate',['../group___s_t_m32_f4xx___system___private___functions.html#gae0c36a9591fe6e9c45ecb21a794f0f0f',1,'system_stm32f4xx.c']]],
  ['systeminit_5',['SystemInit',['../group___s_t_m32_f4xx___system___private___functions.html#ga93f514700ccf00d08dbdcff7f1224eb2',1,'system_stm32f4xx.c']]],
  ['systick_5fhandler_6',['SysTick_Handler',['../stm32f4xx__it_8c.html#ab5e09814056d617c521549e542639b7e',1,'stm32f4xx_it.c']]]
];
