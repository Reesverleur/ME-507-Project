var searchData=
[
  ['data_0',['Data',['../class_pixy2.html#aa8af39f57cd9f4fe191fc560ef761926',1,'Pixy2']]],
  ['derror_1',['derror',['../class_motor.html#aae158f1e157fdcf8025816a680f55be1',1,'Motor']]],
  ['duty_2',['Duty',['../class_motor.html#a98874168e7395ecd24077dffb1f045fd',1,'Motor']]]
];
