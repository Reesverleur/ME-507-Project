var searchData=
[
  ['block_0',['Block',['../class_pixy2.html#a1f52f01612a384324ca724557f3b660e',1,'Pixy2']]],
  ['blu_5fval_1',['Blu_Val',['../class_c_sens.html#aa99d02835daf65e4baa53f817778a4af',1,'CSens']]]
];
