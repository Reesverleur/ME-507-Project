var searchData=
[
  ['red_5fval_0',['Red_Val',['../class_c_sens.html#a5ecef084ece6e281c72789920f7412dc',1,'CSens']]],
  ['revch_1',['RevCh',['../class_motor.html#a2bc952e0a163cfce19910382aa29e3c5',1,'Motor']]]
];
