var searchData=
[
  ['ticks_0',['ticks',['../class_motor.html#a1488c62593760ccd830dd139a226d149',1,'Motor']]],
  ['tim_1',['tim',['../class_motor.html#a1867a8b2977e1babab19e7e87db8ce07',1,'Motor']]]
];
