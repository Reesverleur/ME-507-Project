var searchData=
[
  ['setpoint_0',['setpoint',['../class_motor.html#ab6855c76809c900fcc0ceb51325fbbf7',1,'Motor']]],
  ['spi_1',['spi',['../class_pixy2.html#a49f19b0f16a7f2aac4ed828f308c547d',1,'Pixy2']]],
  ['ss_5fpin_2',['SS_Pin',['../class_pixy2.html#af55d898a6bde47ead0588ea66aed2b1c',1,'Pixy2']]],
  ['ss_5fport_3',['SS_Port',['../class_pixy2.html#a75a4ee39e2cecd3391825d84cfbb5020',1,'Pixy2']]],
  ['startbyte_4',['StartByte',['../class_pixy2.html#aaa32690b46c6fc32298c63eaa48be9a6',1,'Pixy2']]]
];
