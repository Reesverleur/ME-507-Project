var searchData=
[
  ['getblock_0',['getBlock',['../class_pixy2.html#acd9f3a548eed9c7348c14619affbab9b',1,'Pixy2']]],
  ['getcdata_1',['getCdata',['../class_c_sens.html#a4f6a194a321d5e50883bc19add1067b4',1,'CSens']]],
  ['grn_5fval_2',['Grn_Val',['../class_c_sens.html#abf222dae6f684d88df32237e3a8315be',1,'CSens']]]
];
