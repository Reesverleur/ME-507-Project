var indexSectionsWithContent =
{
  0: "_abcdefghiklmnoprstuvz",
  1: "cmp",
  2: "cmps",
  3: "_bcdeghimnpsuvz",
  4: "_abcdefgiklmoprst",
  5: "cs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Modules"
};

